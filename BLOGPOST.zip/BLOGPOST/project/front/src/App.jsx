import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";

import Login from "./components/loginPage";
import Register from "./components/registerPage";
import ForgotPassword from "./components/forgottenPage";
import Mypost from "./components/myPosts";
import Post from "./components/post";

function App() {
  return (
    <BrowserRouter>
      <header>
        <h1>Blog</h1>
      </header>

      <Routes>
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register isEdit={false} />} />
        <Route path="/my-posts" element={<Mypost />} />
        <Route path="/create-post" element={<Post />} />
      </Routes>


    </BrowserRouter>
  );
}

export default App;
