import axios from "axios";

const API_BASE_URL = "http://localhost:4000/api";

const getToken = () => localStorage.getItem("token");

export const register = async (userData) => {
  const response = await axios.post(`${API_BASE_URL}/users/register`, userData);
  return response.data;
};

export const resetPassword = async ({ email, newPassword }) => {
  const response = await axios.post(`${API_BASE_URL}/users/reset-password`, { email, newPassword });
  return response.data;
};

export const login = async (credentials) => {
  const response = await axios.post(`${API_BASE_URL}/users/login`, credentials);

  if (response.data && response.data.token) {
    localStorage.setItem("token", response.data.token);
    localStorage.setItem("user", JSON.stringify(response.data.user));
  }
  return response.data;
};

export const createPost = async ({ title, content, imageUrl }) => {
  const token = getToken();
  if (!token) {
    throw new Error("User not authenticated. Please log in.");
  }
  const response = await axios.post(`${API_BASE_URL}/posts`, { title, content, imageUrl }, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.data;
};

export const deletePost = async (postId) => {
  const token = getToken();
  if(!token){
    throw new Error("User not authenticated. Please log in.");
  }
  const response = await axios.delete(`${API_BASE_URL}/posts/${postId}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    }
  });
  return response.data;
};

export const updatePost = async (postId, updates) => {
  const token = getToken();   
  if(!token){
    throw new Error("User not authenticated. Please log in.");
  }
  const response = await axios.put(`${API_BASE_URL}/posts/${postId}`, updates, {
    headers: {
      Authorization: `Bearer ${token}`,
    }
  });
  return response.data;
}

export const fetchUserPosts = async () => {
  const token = getToken();
  if(!token){
    throw new Error("User not authenticated. Please log in.");
  }

  const response = await axios.get(`${API_BASE_URL}/posts/my-post`, {
    headers: {
      Authorization: `Bearer ${token}`,
    }
  });
  return response.data;
};

export const fetchAllPosts = async () => {
  const token = getToken();
  if(!token){
    throw new Error("User not authenticated. Please log in.");
  }

  const response = await axios.get(`${API_BASE_URL}/user`, {
    headers: {
      Authorization: `Bearer ${token}`,
    }
  });
  return response.data;
} 

export const fetchAllPublicPosts = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/posts`);
    return response.data;
  } catch (error) {
    console.error("Failed to fetch public posts:", error);
    throw error;
  }
};


export const likePost = async (postId) => {
  const token = getToken();
  if(!token){
    throw new Error("User not authenticated. Please log in.");
  }
  
  const response = await axios.post(`${API_BASE_URL}/likes/like/${postId}`, {}, {
    headers: {
      Authorization: `Bearer ${token}`,
    }
  });
  return response.data;
}

export const unlikePost = async (postId) => {
  const token = getToken();
  if (!token) {
    throw new Error("User not authenticated. Please log in.");
  }

  const response = await axios.delete(`${API_BASE_URL}/likes/unlike/${postId}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    }
  });
  return response.data;
}

export const addComment = async ({ post_id, content }) => {
  const token = getToken();
  if (!token) {
    throw new Error("User not authenticated. Please log in.");
  }
  const response = await axios.post(`${API_BASE_URL}/comments/comment`, { post_id, content }, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.data;
};

export const updateUser = async (userId, updates) => {
  const token = getToken();
  if (!token) {
    throw new Error("User not authenticated. Please log in.");
  }
  const response = await axios.put(`${API_BASE_URL}/users/${userId}`, updates, {
    headers: {
      Authorization: `Bearer ${token}`,
    }
  });
  if (response.data && response.data.user) {
    localStorage.setItem("user", JSON.stringify(response.data.user));
  }
  return response.data;
};

export const deleteComment = async (commentId) => {
  const token = getToken();
  if (!token) {
    throw new Error("User not authenticated. Please log in.");
  }
  const response = await axios.delete(`${API_BASE_URL}/comments/${commentId}`, { 
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
  return response.data;
};