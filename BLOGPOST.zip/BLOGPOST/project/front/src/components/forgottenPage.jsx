import React, { useState, } from "react";
import { useNavigate,Link } from "react-router-dom";
import { resetPassword } from "../services/api.js";  

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSending(true);
    setSuccessMessage("");
    setErrorMessage("");

    try {
      await resetPassword({ email, newPassword }); 
      setSuccessMessage("Password has been reset successfully.");

      setTimeout(() => {
        navigate("/login");
      }, 1500);
    } catch (err) {
      setErrorMessage(
        err.response?.data?.message || "Failed to reset password. Please try again."
      );
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="login-container">
      <form onSubmit={handleSubmit} className="login-form">
        <h2 className="form-title">Forgot Password</h2>

        

        <div className="form-group">
          <label htmlFor="email" className="form-label">
            Enter your email
          </label>
          <input
            type="email"
            id="email"
            name="email"
            className="form-input"
            placeholder="Email address"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label htmlFor="newPassword" className="form-label">
            Enter your new password
          </label>
          <input
            type="password"
            id="newPassword"
            name="newPassword"
            className="form-input"
            placeholder="New password"
            required
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />
        </div>
        {successMessage && <p style={{ color: "green" }}>{successMessage}</p>}
        {errorMessage && <p style={{ color: "red" }}>{errorMessage}</p>}
        {isSending && <p>Processing...</p>}
        <button type="submit" className="submit-button" disabled={isSending}>
          Reset Password
        </button>
        <div className="signup-link">
          Don't have an account? <Link to="/register">Sign up</Link>
        </div>
      </form>
    </div>
  );
}
