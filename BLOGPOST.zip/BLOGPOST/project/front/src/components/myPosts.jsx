import { fetchUserPosts, deletePost, updatePost, fetchAllPublicPosts, likePost, unlikePost, addComment, updateUser, deleteComment } from "../services/api.js";
import { useState, useEffect, useCallback } from "react"; 
import { useNavigate } from "react-router-dom";


export default function Mypost() {
    const [currentUserState, setCurrentUserState] = useState(() => {
        const storedUser = JSON.parse(localStorage.getItem("user"));
        console.log("Initial currentUserState from localStorage:", storedUser);
        console.log("Initial bio from localStorage:", storedUser?.bio);
        return storedUser;
    });

    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [searchQuery, setSearchQuery] = useState("");
    const [confirmationMessage, setConfirmationMessage] = useState("");
    const [editUsername, setEditUsername] = useState(currentUserState?.username || "");
    const [editBio, setEditBio] = useState(currentUserState?.bio || "");
    const [errorMessage, setErrorMessage] = useState("");
    const [newCommentContent, setNewCommentContent] = useState({});
    const [showingCommentsForPost, setShowingCommentsForPost] = useState(null);
    const [editingProfile, setEditingProfile] = useState(false);
    const [profileImageUrl, setProfileImageUrl] = useState(currentUserState?.profileImageUrl || "");
    const navigate = useNavigate();

    useEffect(() => {
        if (currentUserState) {
            setEditUsername(currentUserState.username || "");
            setProfileImageUrl(currentUserState.profileImageUrl || "");
            setEditBio(currentUserState.bio || "");
        }
    }, [currentUserState, editingProfile]);

    const loadPosts = useCallback(async () => {
        setLoading(true);
        setError(null);
        const currentUserId = currentUserState?.id; 
        try {
            const data = await fetchAllPublicPosts();
            if (data.posts) {
                const processPosts = data.posts.map(post => ({
                    ...post,
                    likedByUser: post.likes ? post.likes.some(like => String(like.user_id) === String(currentUserId)) : false,
                    likes_count: post.likes ? post.likes.length : 0,
                    comments: post.comments ? post.comments.map(comment => ({
                        ...comment,
                        user: comment.user || { username: 'Unknown', profileImageUrl: '/images/image_b1d686.png' }
                    })) : []
                }));
                setPosts(processPosts);
            } else {
                setPosts([]);
            }
        } catch (err) {
            console.error("Error fetching posts:", err);
            if (err.message && (err.message.includes("authenticated") || err.message.includes("token"))) {
                setError("Session expired or not authenticated. Please log in to view posts.");
            } else {
                setError(err.message || "Failed to load posts. Please try again later.");
            }
            setPosts([]);
        } finally {
            setLoading(false);
        }
    }, [currentUserState?.id]);

    useEffect(() => {
        if (currentUserState?.id) {
            loadPosts();
        }
    }, [currentUserState?.id, loadPosts]); 


    const handleDelete = async (postId) => {
        try {
            await deletePost(postId);
            setPosts((prevPosts) => prevPosts.filter((post) => (post.post_id || post.id) !== postId));
            
        } catch (error) {
            console.error("Failed to delete post:", error);
            setErrorMessage("Failed to delete post. Please try again.");
            setTimeout(() => setErrorMessage(""), 3000);
        }
    };

    const handleEdit = (post) => {
        navigate('/create-post', { state: { postToEdit: post } });
    };

    const handleLike = async (postId, currentlyLiked) => {
        try {
            if (currentlyLiked) {
                await unlikePost(postId);
                setPosts((prevPosts) =>
                    prevPosts.map((post) =>
                        (post.post_id || post.id) === postId ?
                            {
                                ...post,
                                likedByUser: false,
                                likes_count: (post.likes_count || 0) - 1
                            } :
                            post
                    )
                );
            } else {
                await likePost(postId);
                setPosts((prevPosts) =>
                    prevPosts.map((post) =>
                        (post.post_id || post.id) === postId ?
                            {
                                ...post,
                                likedByUser: true,
                                likes_count: (post.likes_count || 0) + 1
                            } :
                            post
                    )
                );
            }
        } catch (error) {
            console.error("Failed to toggle like status:", error);
            if (error.response && error.response.status === 409) {
                setErrorMessage("You have already liked this post.");
                if (!currentlyLiked) {
                    setPosts((prevPosts) =>
                        prevPosts.map((post) =>
                            (post.post_id || post.id) === postId ?
                                { ...post, likedByUser: true } :
                                post
                        )
                    );
                }
            } else if (error.response && error.response.status === 404) {
                setErrorMessage("Like not found or already unliked.");
            } else {
                setErrorMessage("Failed to update like status. Please try again.");
            }
            setTimeout(() => setErrorMessage(""), 3000);
        }
    };

    const handleCommentChange = (postId, value) => {
        setNewCommentContent(prev => ({ ...prev, [postId]: value }));
    };

    const handleAddComment = async (e, postId) => {
        e.preventDefault();
        const content = newCommentContent[postId]?.trim();
        if (!content) {
            setErrorMessage("Comment cannot be empty.");
            setTimeout(() => setErrorMessage(""), 3000);
            return;
        }
        
        const currentLocalUser = JSON.parse(localStorage.getItem("user")); 
        if (!currentLocalUser) {
            setErrorMessage("User not logged in or session expired. Please log in to comment.");
            setTimeout(() => setErrorMessage(""), 3000);
            return;
        }

        console.log("handleAddComment: currentLocalUser from localStorage:", currentLocalUser);
        console.log("handleAddComment: profileImageUrl for new comment:", currentLocalUser.profileImageUrl);

        try {
            const newComment = await addComment({ post_id: postId, content });
            
            setPosts(prevPosts =>
                prevPosts.map(post =>
                    (post.post_id || post.id) === postId
                        ? {
                            ...post,
                            comments: [
                                ...(post.comments || []),
                                {
                                    ...newComment,
                                    user: {
                                        username: currentLocalUser.username || 'You',
                                        profileImageUrl: currentLocalUser.profileImageUrl || 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y'
                                    }
                                }
                            ]
                        }
                        : post
                )
            );
            setNewCommentContent(prev => ({ ...prev, [postId]: '' })); 
            
        } catch (error) {
            console.error("Failed to add comment:", error);
            setErrorMessage("Failed to add comment. Please try again.");
            setTimeout(() => setErrorMessage(""), 3000);
        }
    };

    const handleDeleteComment = async (commentId, postId) => {
        
        try {
            await deleteComment(commentId);
            setPosts(prevPosts =>
                prevPosts.map(post =>
                    (post.post_id || post.id) === postId
                        ? {
                            ...post,
                            comments: post.comments.filter(comment => comment.id !== commentId)
                        }
                        : post
                )
            );
            
        } catch (error) {
            console.error("Failed to delete comment:", error);
            let message = "Failed to delete comment.";
            if (error.response && error.response.data && error.response.data.message) {
                message = error.response.data.message;
            } else if (error.message) {
                message = error.message;
            }
            setErrorMessage(message);
            setTimeout(() => setErrorMessage(""), 3000);
        }
    };

    const toggleCommentsVisibility = (postId) => {
        setShowingCommentsForPost(prevId => (prevId === postId ? null : postId));
    };

    const handleProfileUpdate = async (e) => {
        e.preventDefault();
        const newUsername = editUsername.trim() ? editUsername : currentUserState.username;

        console.log("Attempting to update profile with:", {
            username: newUsername,
            profileImageUrl,
            bio: editBio
        });
        console.log("Bio value being sent:", editBio);

        try {
            const result = await updateUser(currentUserState.id, {
                username: newUsername,
                profileImageUrl,
                bio: editBio
            });

            console.log("API update result (full object):", JSON.stringify(result, null, 2));
            console.log("API update result - user object:", result.user);
            console.log("API update result - user bio:", result.user?.bio);

            localStorage.setItem("user", JSON.stringify(result.user));
            console.log("User stored in localStorage (full object):", JSON.parse(localStorage.getItem("user")));
            console.log("Bio stored in localStorage:", JSON.parse(localStorage.getItem("user"))?.bio);

            setCurrentUserState(result.user); 
            console.log("New currentUserState (full object):", result.user);
            console.log("New currentUserState bio:", result.user?.bio);
            console.log("New currentUserState profileImageUrl:", result.user?.profileImageUrl);

            await loadPosts(); 

            setEditingProfile(false);
            
        } catch (error) {
            console.error("Failed to update profile:", error);
            let message = "Failed to update profile.";
            if (error.response && error.response.data && error.response.data.message) {
                message = error.response.data.message;
            } else if (error.message) {
                message = error.message;
            }
            setErrorMessage(message);
            setTimeout(() => setErrorMessage(""), 3000);
        }
    };

    const handleCreatePost = () => {
        navigate('/create-post');
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        setCurrentUserState(null); 
        navigate("/login");
    };

    const filteredPosts = posts.filter(post =>
        post.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    let postsContent;
    if (loading) {
        postsContent = <p className="status-message">Loading posts...</p>;
    } else if (error) {
        postsContent = <p className="error-message">Error: {error}</p>;
    } else if (posts.length === 0 && searchQuery.length === 0) {
        postsContent = <p className="status-message">No posts yet. Be the first to create one!</p>;
    } else if (filteredPosts.length === 0 && searchQuery.length > 0) {
        postsContent = <p className="status-message">No posts found matching your search: "{searchQuery}"</p>;
    } else {
        postsContent = (
            <div className="article-list">
                {filteredPosts.map((post) => (
                    <div key={post.post_id || post.id} className="article-card">
                        <div className="article-image-container">
                        {post.imageUrl && (
                            <img
                                src={post.imageUrl}
                                alt="Post"
                                className="post-image"
                                style={{ maxWidth: "100%", maxHeight: "100%", marginBottom: "10px" }}
                            />
                        )}</div>
                        <>
                            <div className="article-title">{post.title}</div>
                            <div className="article-snippet">{post.content}</div>
                            <div className="article-author">
                                {post.user && post.user.profileImageUrl && (
                                    <img
                                        src={post.user.profileImageUrl}
                                        alt={`${post.user.username}'s profile`}
                                        className="post-author-profile-picture"
                                        style={{ width: "30px", height: "30px", borderRadius: "50%", marginRight: "8px", verticalAlign: "middle", objectFit: "cover" }}
                                    />
                                )}
                                Posted by {post.user ? post.user.username : "Unknown Author"} on{" "}
                                {new Date(post.created_at || post.createdAt).toLocaleString()}
                            </div>
                            <div className="post-actions">
                                {(currentUserState && (post.user_id === currentUserState.id || post.user?.id === currentUserState.id)) && (
                                    <>
                                        <button onClick={() => handleEdit(post)} className="edit-button">
                                            Edit
                                        </button>
                                        <button onClick={() => handleDelete(post.post_id || post.id)} className="delete-button">
                                            Delete
                                        </button>
                                    </>
                                )}
                                <button
                                    onClick={() => handleLike(post.post_id || post.id, post.likedByUser)}
                                    className="like-button"
                                >
                                    {post.likedByUser ? `Unlike (${post.likes_count || 0})` : `Like (${post.likes_count || 0})`}
                                </button>

                                <button onClick={() => toggleCommentsVisibility(post.post_id || post.id)} className="comment-button">
                                    Comment ({post.comments ? post.comments.length : 0})
                                </button>
                            </div>

                            {(showingCommentsForPost === (post.post_id || post.id)) && (
                                <div className="comments-section">
                                    <h4>Comments</h4>
                                    {post.comments && post.comments.length > 0 ? (
                                        <ul className="comments-list">
                                            {post.comments.map(comment => (
                                                <li key={comment.id} className="comment-item">
                                                    {comment.user ? (
                                                        <img
                                                            src={comment.user.profileImageUrl || 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y'}
                                                            alt={`${comment.user.username}'s profile`}
                                                            className="comment-profile-picture"
                                                            style={{ width: "30px", height: "30px", borderRadius: "50%", marginRight: "8px", objectFit: "cover" }}
                                                        />
                                                    ) : (
                                                        <img
                                                            src={'/images/image_b1d686.png'}
                                                            alt="Unknown user's profile"
                                                            className="comment-profile-picture"
                                                            style={{ width: "30px", height: "30px", borderRadius: "50%", marginRight: "8px", objectFit: "cover" }}
                                                        />
                                                    )}
                                                    <strong>{comment.user ? comment.user.username : 'Unknown'}:</strong> {comment.content}
                                                    <span className="comment-date">
                                                        {" "} - {new Date(comment.createdAt || comment.created_at).toLocaleString()}
                                                    </span>
                                                    {(currentUserState && (comment.user_id === currentUserState.id || comment.user?.id === currentUserState.id)) && (
                                                        <button
                                                            onClick={() => handleDeleteComment(comment.id, (post.post_id || post.id))}
                                                            className="delete-comment-button"
                                                            style={{ marginLeft: '10px', padding: '5px 10px', fontSize: '0.8em', backgroundColor: '#dc3545', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
                                                        >
                                                            Delete
                                                        </button>
                                                    )}
                                                </li>
                                            ))}
                                        </ul>
                                    ) : (
                                        <p className="no-comments">No comments yet. Be the first to comment!</p>
                                    )}
                                    <form onSubmit={(e) => handleAddComment(e, (post.post_id || post.id))} className="comment-form">
                                        <textarea
                                            placeholder="Write a comment..."
                                            value={newCommentContent[post.post_id || post.id] || ''}
                                            onChange={(e) => handleCommentChange(post.post_id || post.id, e.target.value)}
                                            className="comment-input"
                                            rows="2"
                                        ></textarea>
                                        <button type="submit" className="submit-comment-button">Add Comment</button>
                                    </form>
                                </div>
                            )}
                        </>
                    </div>
                ))}
            </div>
        );
    }

    return (
        <div className="grid-container">
            <div className="grid-item">
                <div className="profile-content">
                    {currentUserState && (
                        <>
                            <img
                                src={currentUserState.profileImageUrl || 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y'}
                                alt="Profile"
                                className="profile-picture"
                                style={{ width: "80px", height: "80px", borderRadius: "50%", objectFit: "cover", marginBottom: "10px" }}
                            />
                            <p><strong>Username:</strong> {currentUserState.username}</p>
                            <p><strong>Bio:</strong> {currentUserState.bio || "No bio set."}</p>
                        </>
                    )}


                    {confirmationMessage && <p className="success-message">{confirmationMessage}</p>}
                    {errorMessage && <p className="error-message">{errorMessage}</p>}
                </div>
                {!editingProfile ? (
                    <button onClick={() => setEditingProfile(true)} className="create-post-button">Edit Profile</button>
                ) : (
                    <form onSubmit={handleProfileUpdate} className="edit-profile-form">
                        <label className="form-label">Username</label>
                        <input
                            type="text"
                            value={editUsername}
                            onChange={e => setEditUsername(e.target.value)}
                            placeholder="Edit username"
                            className="form-input"
                        />
                        <label className="form-label">Profile Image URL</label>
                        <input
                            type="text"
                            value={profileImageUrl}
                            onChange={e => setProfileImageUrl(e.target.value)}
                            placeholder="Enter new profile image URL"
                            className="form-input"
                        />
                        <label className="form-label">Bio</label>
                        <textarea
                            value={editBio}
                            onChange={e => setEditBio(e.target.value)}
                            placeholder="Tell us about yourself..."
                            className="form-input"
                            rows="4"
                        ></textarea>
                        <button type="submit" className="submit-button">Save</button>
                        <button type="button" onClick={() => setEditingProfile(false)} className="cancel-button">Cancel</button>
                    </form>
                )}
                <button onClick={handleLogout} className="create-post-button">Log Out </button>
                <button onClick={handleCreatePost} className="create-post-button">Create New Post</button>

            </div>

            <div className="grid-item">
                <div className="search-bar">
                    <input
                        type="text"
                        placeholder="Search posts by title..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
                {errorMessage && <p className="error-message">{errorMessage}</p>}
                {postsContent}
            </div>
        </div>
    );
}