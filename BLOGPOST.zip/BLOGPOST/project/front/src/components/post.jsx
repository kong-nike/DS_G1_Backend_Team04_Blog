import { createPost, updatePost } from "../services/api.js"; 
import { useNavigate, useLocation } from "react-router-dom"; 
import React, { useState, useEffect } from "react";

export default function PostForm() { 
    const [title, setTitle] = useState("");
    const [content, setContent] = useState("");
    const [imageUrl, setImageUrl] = useState("");
    const [userId, setUserId] = useState(null); 
    const [isEditing, setIsEditing] = useState(false); 
    const [postId, setPostId] = useState(null); 
    const [errorMessage, setErrorMessage] = useState("");
    const [successMessage, setSuccessMessage] = useState("");


    const navigate = useNavigate();
    const location = useLocation(); 

    useEffect(() => {
        const user = JSON.parse(localStorage.getItem("user"));
        if (user && (user.id || user.user_id)) {
            setUserId(user.id || user.user_id);
        } else {
            setUserId(null);
        }

        if (location.state && location.state.postToEdit) {
            const post = location.state.postToEdit;
            setTitle(post.title || "");
            setContent(post.content || "");
            setImageUrl(post.imageUrl || ""); 
            setPostId(post.post_id || post.id); 
            setIsEditing(true); 
        } else {
            setTitle("");
            setContent("");
            setImageUrl("");
            setPostId(null);
            setIsEditing(false);
        }
    }, [location.state]); 

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!title.trim() || !content.trim()) {
            setErrorMessage("Title and content are required.");
            setTimeout(() => setErrorMessage(""), 3000);
            return;
        }

        try {
            if (isEditing) {
                await updatePost(postId, { title, content, imageUrl });
            } else {
                await createPost({ title, content, imageUrl });
            }

            setPostId(null);
            setIsEditing(false);
            navigate('/my-posts');

        } catch (error) {
            console.error(`Failed to ${isEditing ? 'update' : 'create'} post:`, error);
            setErrorMessage(`Failed to ${isEditing ? 'update' : 'create'} post. Please try again.`);
            setTimeout(() => setErrorMessage(""), 3000);
        }
    };

    const handleCancel = () => {
        navigate('/my-posts'); 
    };

    return (
        <div className="login-container"> 
            <form onSubmit={handleSubmit} className="login-form"> 
                <h2 className="form-title">{isEditing ? "Edit Post" : "Create a Post"}</h2>
                {errorMessage && <p className="error-message">{errorMessage}</p>}
                {successMessage && <p className="success-message">{successMessage}</p>}


                <div className="form-group">
                    <label htmlFor="title" className="form-label">Title</label>
                    <input
                        type="text"
                        id="title"
                        name="title"
                        className="form-input"
                        placeholder="Enter post title"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="content" className="form-label">Content</label>
                    <textarea
                        id="content"
                        name="content"
                        className="form-input"
                        placeholder="Write your post content here"
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="imageUrl" className="form-label">Image URL (Optional)</label>
                    <input
                        type="text"
                        id="imageUrl"
                        name="imageUrl"
                        className="form-input"
                        placeholder="Paste an image URL here (e.g., https://example.com/image.jpg)"
                        value={imageUrl}
                        onChange={(e) => setImageUrl(e.target.value)}
                    />
                    
                    {imageUrl && (
                        <div style={{ marginTop: '10px' }}>
                            <p>Image Preview:</p>
                            <img src={imageUrl} alt="Image Preview" style={{ maxWidth: "200px", maxHeight: "200px", border: "1px solid #ddd" }} />
                        </div>
                    )}
                </div>

                <div className="form-actions">
                    <button type="submit" className="submit-button" disabled={!userId && !isEditing}>
                        {isEditing ? "Update Post" : (userId ? "Create Post" : "Log in to post")}
                    </button>
                    <button type="button" onClick={handleCancel} className="submit-button">
                        Cancel
                    </button>
                </div>
            </form>

        </div>
    );
}