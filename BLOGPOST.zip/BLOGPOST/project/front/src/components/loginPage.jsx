import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { login } from '../services/api.js'; 

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

const handleSubmit = async (e) => {
  e.preventDefault();
  setError('');

  try {
    const response = await login({ email, password });
    console.log("Login response:", response);
    localStorage.setItem("user", JSON.stringify(response.user));
    localStorage.setItem("token", response.token); 

    navigate(`/my-posts`); 
  } catch (err) {
    console.error("Login error:", err);
    setError(err.response?.data?.message || "Login failed.");
  }
};

  return (
    <div className="login-container">
      <form onSubmit={handleSubmit} className="login-form">
        <h2 className="form-title">Login</h2>


        <div className="form-group">
          <label htmlFor="email" className="form-label">Email</label>
          <input
            type="text"
            id="email"
            name="email"
            className="form-input"
            placeholder='Enter your email'
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="form-group">
          <label htmlFor="password" className="form-label">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            className="form-input"
            placeholder='Enter your password'
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        {error && <p style={{ color: 'red' }}>{error}</p>}

        <div className="form-options">
          <Link to="/forgot-password" className="forgot-link">Forgot your password?</Link>
        </div>

        <button type="submit" className="submit-button">
          Sign In
        </button>

        <div className="signup-link">
          Don't have an account? <Link to="/register">Sign up</Link>
        </div>
        
      </form>
    </div>
  );
}

export default Login;
