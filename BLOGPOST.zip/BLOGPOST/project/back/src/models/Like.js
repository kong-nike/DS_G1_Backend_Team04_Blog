    import { DataTypes } from 'sequelize';

    const LikeModel = (sequelize) => {
        const Like = sequelize.define('likes', {
            user_id: {  
                type: DataTypes.INTEGER,
                allowNull: false,   
                references: {
                    model: 'users', 
                    key: 'id',
                },  
            },
            post_id: {  
                type: DataTypes.INTEGER,
                allowNull: false,
                references: {
                    model: 'posts', 
                    key: 'id',
                },
            },
        }, {
            indexes: [
                {
                    unique: true,
                    fields: ['user_id', 'post_id'], 
                },
            ],
        });

        return Like;
    };

    export default LikeModel;
