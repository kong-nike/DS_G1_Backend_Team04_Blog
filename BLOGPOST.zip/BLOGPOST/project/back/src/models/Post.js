import { DataTypes } from 'sequelize';

const PostModel = (sequelize) => {
    const Post = sequelize.define('posts', {
        title: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        content: {
            type: DataTypes.TEXT,
            allowNull: false,
        },
        user_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'users', 
                key: 'id',
            },
        },
        imageUrl: {
            type: DataTypes.STRING,
            allowNull: true,
        },
    });

    return Post;
}

export default PostModel;