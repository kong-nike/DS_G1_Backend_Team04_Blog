import { DataTypes } from 'sequelize';

const CommentModel = (sequelize) => {
    const Comment = sequelize.define('comments', {
        content: {
            type: DataTypes.TEXT,   
            allowNull: false,
        },
        user_id: {  
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'users',
                key: 'id',
            },
        },  
        post_id: {  
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'posts', 
                key: 'id',
            },
        }
    });

    return Comment;
}

export default CommentModel;

