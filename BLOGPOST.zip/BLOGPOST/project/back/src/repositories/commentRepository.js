import sequelize from "../utils/database.js";

export async function createComment({ content, user_id, post_id }) {
    try {
        const newComment = await sequelize.models.comments.create({
            content,
            user_id,
            post_id
        });

        const commentWithUser = await sequelize.models.comments.findByPk(newComment.id, {
            include: [{
                model: sequelize.models.users, 
                as: 'user',
                attributes: ['id', 'username', 'profileImageUrl'] 
            }]
        });

        return commentWithUser;
    } catch (error) {
        console.error("Error creating comment:", error);
        throw error;
    }
}

export async function deleteComment(comment_id, requesting_user_id) {
    try {
        const comment = await sequelize.models.comments.findByPk(comment_id);

        if (!comment) {
            throw new Error("Comment not found.");
        }
        if (comment.user_id !== requesting_user_id) {
            const user = await sequelize.models.users.findByPk(requesting_user_id);
            if (!user || user.role !== 'admin') { 
                 throw new Error("Unauthorized: You can only delete your own comments.");
            }
        }
        await comment.destroy(); 
        return true; 
    } catch (error) {
        console.error("Error deleting comment:", error);
        throw error; 
    }
}
