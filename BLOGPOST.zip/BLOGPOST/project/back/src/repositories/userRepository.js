import sequelize from "../utils/database.js";

export async function createUser(username, email, password) {
  try {
    const newUser = await sequelize.models.users.create({
      username,
      email,
      password
    });
    return newUser;

  } catch (error) {
    console.error("Error creating user:", error);
    throw error;
  }
}

export async function resetPassword(email, newPassword) {
  try {
    const user = await sequelize.models.users.findOne({
      where: { email }
    });

    if (!user) {
      throw new Error("User not found");
    }

    user.password = newPassword;
    await user.save();
    return user;

  } catch (error) {
    console.error("Error resetting password:", error);
    throw error;
  }
} 

export async function loginUser(email) {
  try {
    const user = await sequelize.models.users.findOne({
      where: { email }
    });

    return user;

  } catch (error) {
    console.error("Error fetching user:", error);
    throw error;
  }
}

export async function updateUser(userId, updates) {
  try {
    if (updates.username) {
      const existing = await sequelize.models.users.findOne({
        where: { username: updates.username }
      });
      
    }
    const user = await sequelize.models.users.findByPk(userId);
    if (!user) throw new Error("User not found");
    Object.assign(user, updates);
    await user.save();
    return user;
  } catch (error) {
    console.error("Error updating user:", error);
    throw error;
  }
}
