import sequelize from "../utils/database.js";

export async function findLikeByUserAndPost(userId, postId) {
    try {
        const like = await sequelize.models.likes.findOne({
            where: { user_id: userId, post_id: postId }
        });
        return like;
    } catch (error) {
        console.error("Error finding like by user and post:", error);
        throw error;
    }
}

export async function createLike({ user_id, post_id }) {
    try {
        const newLike = await sequelize.models.likes.create({
            user_id,
            post_id
        });
        return newLike;
    } catch (error) {
        console.error("Error creating like:", error);
        throw error;
    }
}

export async function unlikePost(user_id, post_id) {
    try {
        const like = await findLikeByUserAndPost(user_id, post_id);
        if (like) {
            await like.destroy();
            return true;
        }
        return false;
    } catch (error) {
        console.error("Error unliking post:", error);
        throw error;
    }
}


export async function getLikeCount(postId) {
    try {
        const count = await sequelize.models.likes.count({
            where: { post_id: postId }
        });
        return count;
    } catch (error) {
        console.error("Error fetching like count:", error);
        throw error;
    }
}