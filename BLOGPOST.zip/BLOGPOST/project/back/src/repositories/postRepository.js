import sequelize from "../utils/database.js";

export async function createPost({ title, content, user_id, imageUrl }) {
    try {
        const newPost = await sequelize.models.posts.create({
            title,
            content,
            user_id,
            imageUrl 
        });
        const postWithUser = await sequelize.models.posts.findByPk(newPost.id, {
            include: [{
                model: sequelize.models.users,
                as: 'user',
                attributes: ['id', 'username', 'profileImageUrl'] 
            }]
        });
        return postWithUser;
    } catch (error) {
        console.error("Error creating post:", error);
        throw error;
    }
}

export async function getPostById(postId) {
    try { 
        const post = await sequelize.models.posts.findByPk(postId, {
            include: [{
                model: sequelize.models.users,
                as: 'user',
                attributes: ['id', 'username', 'profileImageUrl'] 
            },
            {
                model: sequelize.models.comments,
                as: 'comments',
                include: [{
                    model: sequelize.models.users,
                    as: 'user',
                    attributes: ['id', 'username', 'profileImageUrl']
                }]
            }
            ]
        });
        if (!post) {
            throw new Error("Post not found");
        }
        return post;
    } catch (error) {
        console.error("Error fetching post by ID:", error);
        throw error;
    }   
}

export async function getPostsByUserId(userId) {
    try {
        const posts = await sequelize.models.posts.findAll({
            where: { user_id: userId },
            order: [['createdAt', 'DESC']],
            include: [{
                model: sequelize.models.users,
                as: 'user',
                attributes: ['id', 'username', 'profileImageUrl'] 
            }]
        });
        return posts;
    } catch (error) {
        console.error("Error fetching posts by user ID:", error);
        throw error;
    }
}


export async function updatePost(postId, updates) {
    try {
        const post = await sequelize.models.posts.findByPk(postId);
        if (!post) {
            throw new Error("Post not found");
        }
        await post.update(updates);

        const updatedPostWithAssociations = await sequelize.models.posts.findByPk(postId, {
            include: [
                {
                    model: sequelize.models.users,
                    as: 'user',
                    attributes: ['id', 'username', 'profileImageUrl']
                },
                {
                    model: sequelize.models.likes,
                    as: 'likes',
                    attributes: ['user_id'],
                    duplicating: false
                },
                {
                    model: sequelize.models.comments,
                    as: 'comments',
                    include: [{
                        model: sequelize.models.users,
                        as: 'user',
                        attributes: ['id', 'username', 'profileImageUrl'] 
                    }]
                }
            ]
        });
        return updatedPostWithAssociations;

    } catch (error) {
        console.error("Error updating post:", error);
        throw error;
    }
}

export async function deletePost(postId) {
    try {
        const post = await sequelize.models.posts.findByPk(postId);
        if (!post) {
            throw new Error("Post not found");
        }
        await post.destroy();
        return { message: "Post deleted successfully" };
    } catch (error) {
        console.error("Error deleting post:", error);
        throw error;
    }
}

export async function getAllPublicPosts() {
    try {
        const posts = await sequelize.models.posts.findAll({
            order: [['createdAt', 'DESC']],
            include: [
                {
                    model: sequelize.models.users,
                    as: 'user',
                    attributes: ['id', 'username', 'profileImageUrl'] 
                },
                {
                    model: sequelize.models.likes,
                    as: 'likes',
                    attributes: ['user_id']
                },
                {
                    model: sequelize.models.comments, 
                    as: 'comments', 
                    include: [{
                        model: sequelize.models.users,
                        as: 'user',
                        attributes: ['id', 'username', 'profileImageUrl'] 
                    }]
                }
            ]
        });
        return posts;
    } catch (error) {
        console.error("Error fetching all public posts:", error);
        throw error;
    }
}
