import express from 'express';
import UserController from '../controllers/userController.js';

const router = express.Router();

router.post('/register', UserController.registerUser);
router.post('/reset-password', UserController.resetPassword);
router.post('/login', UserController.loginUser);
router.put('/:id', UserController.updateUser);

export default router;