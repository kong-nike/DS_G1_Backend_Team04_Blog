import express from "express";
import LikeController from "../controllers/likeController.js";
import auth from "../middleware/auth.js";

const router = express.Router();

router.post('/like/:postId', auth, LikeController.likePost);
router.delete('/unlike/:postId', auth, LikeController.unlikePost)

export default router;