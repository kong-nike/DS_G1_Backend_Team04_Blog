import express from "express";
import CommentController from "../controllers/commentController.js";
import auth from "../middleware/auth.js";

const router = express.Router();

router.post('/comment', auth, CommentController.addComment);
router.delete('/:id', auth, CommentController.deleteComment);

export default router;