import express from 'express';
import PostController from '../controllers/postController.js';
import auth from '../middleware/auth.js'; 
import multer from 'multer';

const upload = multer({ dest: 'uploads/' }); 
const router = express.Router();

router.post('/', auth, upload.single('image'), PostController.createPost);

router.get('/my-post', auth, PostController.getPostByAuthenticatedUser)
router.put('/:id', auth, PostController.updatePost);
router.delete('/:id', auth, PostController.deletePost);

router.get('/', PostController.getAllPublicPosts); 

export default router;