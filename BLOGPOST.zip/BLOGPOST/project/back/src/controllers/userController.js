import * as userRepository from "../repositories/userRepository.js";
import dotenv from "dotenv";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";


dotenv.config();

export const TOKEN_SECRET = process.env.TOKEN_SECRET;

class UserController {

  static async registerUser(req, res) {
    try {
      const { username, email, password } = req.body;
      if (!username || !email || !password) {
        return res.status(400).json({ message: "Username, email, and password are required" });
      }
      const hashedPassword = await bcrypt.hash(password, 10);
      const newUser = await userRepository.createUser(username, email, hashedPassword);
      res.status(201).json({ user: newUser });
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  }

  static async loginUser(req, res) {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }

      const user = await userRepository.loginUser(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRATION });
      res.json({ token, user });
    } catch (error) {
      console.error("Error logging in user:", error);
      res.status(500).json({ message: "Failed to log in user" });
    }
  }

  static async resetPassword(req, res) {
    try {
      const { email, newPassword } = req.body;
      if (!email || !newPassword) {
        console.log("Received body:", req.body);

        return res.status(400).json({ message: "Email and new password are required" });
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      const user = await userRepository.resetPassword(email, hashedPassword);
      res.json({ message: "Password reset successfully", user });
    } catch (error) {
      console.error("Error resetting password:", error);
      res.status(500).json({ message: "Failed to reset password" });
    }
  }

  static async updateUser(req, res) {
    try {
      const userId = req.params.id;
      const { username, profileImageUrl,bio } = req.body;
      const updates = {};
      if (username) updates.username = username;
      if (profileImageUrl) updates.profileImageUrl = profileImageUrl;
      if (bio) updates.bio = bio;
      const updatedUser = await userRepository.updateUser(userId, updates);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({ user: updatedUser });
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  }
}


export default UserController;