import * as likeRepository from '../repositories/likeRepository.js';

class LikeController {

    static async likePost(req, res) {
            try {
                const user_id = req.user.id;
                const post_id  = req.params.postId;

                if (!post_id) {
                    return res.status(400).json({ message: "Post ID is required" });
                }
                
                const existingLike = await likeRepository.findLikeByUserAndPost(user_id, post_id);
                if (existingLike){
                    return res.status(409).json({ message: "Post already liked by this user." });
                }

                const newLike = await likeRepository.createLike({ user_id, post_id });
                res.status(201).json(newLike);
            } catch (error) {
                console.error("Error liking post:", error);
                res.status(500).json({ message: "Failed to like post" });
            }
        }

    static async unlikePost(req, res) {
        try {
            const user_id = req.user.id; 
            const post_id  = req.params.postId;

            if (!post_id || !user_id) {
                return res.status(400).json({ message: "Fak you" })
            }

            const unlike = await likeRepository.unlikePost(user_id, post_id);
            if (unlike){
                res.status(200).json({ message: "Post unliked successfully." });
            } else {
                return res.status(404).json({ message: "Like not found or already unliked." });
            }

        } catch (error) {
            return res.status(500).json( { message: "Internal Server Error during unlike operation." } )
        }
    }

}
    
export default LikeController;

