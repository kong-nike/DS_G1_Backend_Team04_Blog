import * as commentRepository from '../repositories/commentRepository.js';

class CommentController {

    static async addComment(req, res) {
        try {
            const user_id = req.user.id; 
            const { post_id, content } = req.body;

            if (!post_id || !content) {
                return res.status(400).json({ message: "Post ID and content are required" });
            }

            const newComment = await commentRepository.createComment({ content, user_id, post_id });
            res.status(201).json(newComment);
        } catch (error) {
            console.error("Error adding comment:", error);
            res.status(500).json({ message: "Failed to add comment" });
        }
    }
    static async deleteComment(req, res) {
        try {
            const commentId = req.params.id; 
            const requestingUserId = req.user.id; 
            if (!commentId) {
                return res.status(400).json({ message: "Comment ID is required." });
            }
            await commentRepository.deleteComment(commentId, requestingUserId);
            res.status(200).json({ message: "Comment deleted successfully." });
        } catch (error) {
            console.error("Error deleting comment:", error);
            if (error.message.includes("Comment not found")) {
                return res.status(404).json({ message: error.message });
            }
            if (error.message.includes("Unauthorized")) {
                return res.status(403).json({ message: error.message });
            }
            res.status(500).json({ message: "Failed to delete comment." });
        }
    }
}

export default CommentController;