import * as postRepository from "../repositories/postRepository.js";


class PostController {
    
    static async getPostByAuthenticatedUser(req, res) { 
        try {
            const authUserId = req.user.id; 
            if (!authUserId) {
                return res.status(400).json({ message: "User ID is required" });
            }
            console.log("Authenticated user ID:", authUserId); 
            const posts = await postRepository.getPostsByUserId(authUserId);
            res.json({ posts });
        } catch (error) {   
            console.error("Error fetching posts by authenticated user:", error);
            res.status(500).json({ message: "Failed to fetch posts" }); 
        }
    }
    static async createPost(req, res) {
        try {
            const user_id = req.user.id;
            const { title, content } = req.body;
            let imageUrl = null;

            if (req.file) {
                imageUrl = `/uploads/${req.file.filename}`; 
            } else if (req.body.imageUrl) {
                imageUrl = req.body.imageUrl; 
            }

            if (!content) {
                return res.status(400).json({ message: "Content is required" });
            }

            const newPost = await postRepository.createPost({ title, content, user_id, imageUrl });
            res.status(201).json(newPost);
        } catch (error) {
            console.error("Create post error:", error);
            res.status(500).json({ message: "Failed to create post" });
        }
    }

    static async getAllPublicPosts(req, res) {
        try {
            const posts = await postRepository.getAllPublicPosts();
            res.json({ posts });
        } catch (error) {
            console.error("Error fetching all public posts:", error);
            res.status(500).json({ message: "Failed to fetch posts" });
        }   
    }

    static async updatePost(req, res) {
        try {
            const postId = req.params.id;
            const updates = req.body;
            const authUserId = req.user.id; 

            const postToUpdate = await postRepository.updatePost(postId);
            if (!postToUpdate) {
                return res.status(404).json({ message: "Forbidden: You can only update your own posts." });
            }   

            const updatedPost = await postRepository.updatePost(postId, updates);
            res.json(updatedPost);
        } catch (error) {
            console.error("Error updating post:", error);
            res.status(500).json({ message: "Failed to update post" });
        }
    }   

    static async deletePost(req, res) {
        try {
            const postId = req.params.id;
            const authUserId = req.user.id; 

            const postToDelete = await postRepository.getPostById(postId);
            if (!postToDelete) {
                 return res.status(404).json({ message: "Post not found." });
            }
            if (postToDelete.user_id !== authUserId) {
                console.warn(`User ${authUserId} attempted to delete post ${postId} which belongs to ${postToDelete.user_id}`);
                return res.status(403).json({ message: "Forbidden: You can only delete your own posts." });
            }
            const result = await postRepository.deletePost(postId);
            res.json({ message: "Post deleted successfully.", deletedCount: result.deletedCount || 1 });
        } catch (error) {
            console.error("Error deleting post:", error);
            res.status(500).json({ message: "Failed to delete post" });
        }
    }
}

export default PostController;
