// server.js
import app from "./app.js";
import dotenv from "dotenv";
import db from "../src/models/Association.js"; 

dotenv.config();
const PORT = process.env.PORT;

async function startServer() {
  try {
    await db.sequelize.authenticate(); 


    await db.sequelize.sync({alter:true}); 


    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) { 
    console.error("🔴 Error starting server:", error);
    process.exit(1); 
  }
};

startServer();
